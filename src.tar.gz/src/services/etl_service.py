"""
ETL 服务 - 数据抽取与转换

从 MySQL 源数据库同步通话记录到 PostgreSQL 画像存储
包含基于规则引擎的满意度/情绪/风险分析
"""
import asyncio
import json
import os
import uuid
from datetime import date, datetime
from typing import Any, Iterable,List
from src.core.config import settings

from loguru import logger

from sqlalchemy import text
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.database import get_portrait_db, get_source_db, is_source_db_available
from src.models.portrait.call_enriched import CallRecordEnriched
from src.services.rule_engine_service import rule_engine
from src.utils.table_utils import (
    get_call_record_table,
    get_call_record_detail_table,
    get_tables_for_period,
)

import requests


class ETLService:
    """
    ETL 服务类

    负责从源数据库同步通话记录到画像存储
    """

    async def sync_call_records(
        self,
        target_date: date,
        batch_size: int = 100,  # 降低批次大小避免参数过多
    ) -> dict[str, Any]:
        """
        同步指定日期的通话记录

        Args:
            target_date: 目标日期
            batch_size: 批量处理大小

        Returns:
            同步结果统计
        """
        if not is_source_db_available():
            logger.warning("MySQL 源数据库不可用，跳过同步")
            return {"status": "skipped", "reason": "source_db_unavailable"}

        logger.info(f"开始同步 {target_date} 的通话记录")

        # 获取源数据
        source_records = await self._fetch_source_records(target_date)
        if not source_records:
            logger.info(f"{target_date} 没有需要同步的记录")
            return {"status": "success", "synced": 0, "date": str(target_date)}

        logger.info(f"从源库读取到 {len(source_records)} 条记录")

        #if len(source_records) > 5:
        #    logger.info(f"测试模式：只处理前20条记录")
        #    source_records = source_records[:5]


        # 批量保存到画像库
        synced_count = 0
        async for session in get_portrait_db():
            for i in range(0, len(source_records), batch_size):
                batch = source_records[i : i + batch_size]
                try:
                    await self._upsert_enriched_records(session, batch)
                    await session.commit()  # 每批次提交
                    synced_count += len(batch)
                    logger.info(f"已同步 {synced_count}/{len(source_records)} 条记录")
                except Exception as e:
                    logger.error(f"批次同步失败: {e}")
                    await session.rollback()
                    raise

        logger.info(f"同步完成: {synced_count} 条记录")

        # 分析已同步的记录（获取 ASR 并进行规则分析）
        if synced_count > 0:
            analyzed_count = await self.analyze_call_records(target_date)
            logger.info(f"已分析 {analyzed_count} 条记录")

        return {
            "status": "success",
            "synced": synced_count,
            "date": str(target_date),
        }

    async def _fetch_source_records(self, target_date: date) -> list[dict]:
        """
        从源数据库读取通话记录

        Args:
            target_date: 目标日期

        Returns:
            通话记录列表
        """
        # 根据日期确定表名
        table_name = get_call_record_table(target_date)

        # 构建查询 SQL - 注意: 使用 customer_id 而不是 user_id
        # 同时获取 callee (被叫手机号)
        sql = text(f"""
            SELECT 
                cr.id,
                cr.callid,
                cr.task_id,
                cr.customer_id,
                cr.callee,
                DATE(cr.calldate) as call_date,
                cr.duration,
                cr.bill,
                cr.rounds,
                cr.level_name,
                cr.intention_results as intention_result,
                cr.hangup_disposition as hangup_by,
                CASE 
                    WHEN cr.bill > 0 THEN 'connected'
                    ELSE 'failed'
                END as call_status
            FROM {table_name} cr
            WHERE DATE(cr.calldate) = :target_date
        """)

        records = []
        async for session in get_source_db():
            try:
                result = await session.execute(sql, {"target_date": target_date})
                rows = result.fetchall()

                for row in rows:
                    # 转换 MySQL 字符串 UUID 到 Python UUID 对象
                    task_id = row.task_id
                    if isinstance(task_id, str):
                        task_id = uuid.UUID(task_id)

                    # 转换 intention_result 为字符串（MySQL 可能返回整数）
                    intention_result = row.intention_result
                    if intention_result is not None:
                        intention_result = str(intention_result) if intention_result != 0 else None

                    records.append(
                        {
                            "id": row.id,
                            "callid": row.callid,
                            "task_id": task_id,
                            "user_id": row.customer_id,  # 注意: user_id 字段存储 customer_id
                            "phone": row.callee,  # 被叫手机号
                            "call_date": row.call_date,
                            "duration": row.duration or 0,
                            "bill": row.bill or 0,
                            "rounds": row.rounds or 0,
                            "level_name": row.level_name,
                            "intention_result": intention_result,
                            "hangup_by": row.hangup_by,
                            "call_status": row.call_status,
                        }
                    )
            except Exception as e:
                logger.error(f"读取源数据失败: {e}")
                # 检查表是否存在
                if "doesn't exist" in str(e):
                    logger.warning(f"表 {table_name} 不存在")
                raise

        return records

    async def _upsert_enriched_records(
        self,
        session: AsyncSession,
        records: list[dict],
    ) -> None:
        """
        批量插入或更新增强记录

        Args:
            session: 数据库会话
            records: 记录列表
        """
        if not records:
            return

        # 构建 upsert 语句 (PostgreSQL)
        stmt = insert(CallRecordEnriched).values(
            [
                {
                    "callid": r["callid"],
                    "task_id": r["task_id"],
                    "user_id": r["user_id"],
                    "phone": r["phone"],
                    "call_date": r["call_date"],
                    "duration": r["duration"],
                    "bill": r["bill"],
                    "rounds": r["rounds"],
                    "level_name": r["level_name"],
                    "intention_result": r["intention_result"],
                    "hangup_by": r["hangup_by"],
                    "call_status": r["call_status"],
                }
                for r in records
            ]
        )

        # 冲突时更新
        stmt = stmt.on_conflict_do_update(
            index_elements=["callid"],
            set_={
                "duration": stmt.excluded.duration,
                "bill": stmt.excluded.bill,
                "rounds": stmt.excluded.rounds,
                "level_name": stmt.excluded.level_name,
                "intention_result": stmt.excluded.intention_result,
                "hangup_by": stmt.excluded.hangup_by,
                "call_status": stmt.excluded.call_status,
                "phone": stmt.excluded.phone,
                "updated_at": datetime.now(),
            },
        )

        await session.execute(stmt)

    async def analyze_call_records(
        self,
        target_date: date,
        batch_size: int = 100,
    ) -> int:
        """
        分析指定日期的通话记录

        获取 ASR 详情并进行规则引擎分析

        Args:
            target_date: 目标日期
            batch_size: 批量处理大小

        Returns:
            分析的记录数
        """
        if not is_source_db_available():
            return 0

        # 获取需要分析的记录（已接通但未分析的）
        records_to_analyze = await self._get_records_for_analysis(target_date)

        if not records_to_analyze:
            return 0

        logger.info(f"需要分析 {len(records_to_analyze)} 条通话记录")

        # 批量获取 ASR 详情
        asr_data = await self._batch_fetch_asr_details(
            [(r["callid"], r["call_date"]) for r in records_to_analyze],
        )
        logger.info(f"一共有 {len(asr_data)} 条ASR详情记录")

        # 分析并批量更新
        analyzed_count = 0
        updates = []

        for record in records_to_analyze:
            callid = record["callid"]
            logger.info(f"callid: {callid}")
            # 获取该通话的 ASR 数据
            call_asr = asr_data.get(callid, {"qa_pairs": [], "task_id": "", "voice_url": []})
            qa_pairs = call_asr.get("qa_pairs", [])
            qa_pairs_str = json.dumps(qa_pairs,ensure_ascii=False,indent=2)
            logger.info(f"task_id: {call_asr.get('task_id')}")
            logger.info(f"qa_pairs: {call_asr.get('qa_pairs')}")
            # 调用规则引擎分析
            result = await rule_engine.analyze_call(
                qa_pairs=call_asr.get("qa_pairs", []),
                task_id=call_asr.get("task_id", ""),
                voice_url=call_asr.get("voice_url", []),
                duration=record.get("bill", 0) // 1000,  # 毫秒转秒
                rounds=record.get("rounds", 0),
            )
            logger.info(f"result: {result}")

            updates.append(
                {
                    "callid": callid,
                    "qa_pairs": qa_pairs_str,
                    "satisfaction": result.satisfaction,
                    "satisfaction_source": result.satisfaction_source,
                    "satisfaction_llm_res": result.satisfaction_llm_res,
                    "emotion": result.emotion,
                    "emotion_llm_res": result.emotion_llm_res,
                    "emotion_asr_res": result.emotion_asr_res,
                    "complaint_risk": result.complaint_risk,
                    "complaint_llm_res":result.complaint_llm_res,
                    "churn_risk": result.churn_risk,
                    "churn_llm_res": result.churn_llm_res,
                    "willingness": result.willingness,
                    "risk_level": result.risk_level,
                    "unsatisfied_reason": result.unsatisfied_reason,
                    "visit_needed": result.visit_needed,
                    "visit_reason": result.visit_reason,
                    "harassment_risk": result.harassment_risk,
                    "harassment_llm_res": result.harassment_llm_res
                }
            )
            analyzed_count += 1

        # 批量更新
        if updates:
            await self._batch_update_analysis_results(updates)

        return analyzed_count

    async def _get_records_for_analysis(self, target_date: date) -> list[dict]:
        """获取需要分析的记录"""
        async for session in get_portrait_db():
            result = await session.execute(
                text("""
                    SELECT callid, bill, rounds, call_date
                    FROM call_record_enriched
                    WHERE call_date = :target_date
                      AND bill > 0
                      AND (sentiment IS NULL OR satisfaction IS NULL)
                """),
                {"target_date": target_date},
            )
            return [dict(row._mapping) for row in result.fetchall()]
        return []

    async def extract_voice_urls(self, data) -> List[str]:
        """
        递归提取 JSON 内所有 'voice' 字段里的 URL
        忽略 download_voice
        """
        voice_urls = []

        for record in data['data']['records']:
            if record.get('notify') == "asrmessage_notify":
                # 提取 record.voice（字符串）
                voice = record.get('voice')
                if voice:  # 确保 voice 字段存在且不为空
                    voice_urls.append(voice)

        return voice_urls

    async def extract_qa_pairs(self, data):
        """
        从通话记录中提取QA对

        参数:
            data: 原始JSON数据

        返回:
            QA对列表
        """
        records = data['data']['records']
        qa_pairs = []
        current_robot_question = None
        current_node = None

        # for record in records:
        for idx, record in enumerate(records):
            notify = record.get('notify')

            # 处理机器人发言
            # 1. notify == "enter" 时，机器人开场
            if notify == 'enter':
                robot_text = ""
                node_name = record.get('answer_text', '')

                # 从 contents 中提取文本
                if record.get('contents'):
                    robot_text = ' '.join([c['translate_text'] for c in record['contents']])
                elif record.get('answer_content'):
                    content = record['answer_content']
                    lines = content.split('\n')
                    robot_text = '\n'.join([line for line in lines if not line.strip().endswith('秒')])

                # 清理文本
                robot_text = robot_text.strip()
                if ':' in robot_text:
                    parts = robot_text.split(':', 1)
                    if parts[0] in ['Q1', 'Q2', 'Q3', 'Q4', 'Q5', 'Q6', 'Q7', 'Q1-A', 'Q1-default']:
                        robot_text = parts[1].strip()

                current_robot_question = robot_text
                current_node = node_name

            # 2. notify == "asrmessage_notify" 时，可能包含用户回答和机器人新问题
            elif notify == 'asrmessage_notify':
                # 先处理用户回答（如果存在）
                if record.get('question'):
                    user_answer = record['question'].strip()

                    # 提取tags
                    tags_list = []
                    if record.get('tags'):
                        tags_list = [tag['name'] for tag in record['tags']]
                    tags_str = ','.join(tags_list) if tags_list else ''

                    # 关键：检查 answer_content 是否为 null
                    # 如果为 null，说明用户继续说话，需要合并到上一个QA对
                    if record.get('answer_text') is None:
                        # 合并逻辑：找到最后一个相同节点的QA对，合并用户回答
                        if qa_pairs and current_node:
                            last_qa = qa_pairs[-1]
                            # 检查最后一个QA对是否是当前节点
                            if current_node in last_qa:
                                # 合并用户回答
                                last_qa[current_node]['custom'] += ',' + user_answer
                                # 更新tags（如果新的有tags）
                                if tags_str:
                                    last_qa['tags'] = tags_str
                            else:
                                # 如果节点不同，创建新QA对
                                if current_robot_question:
                                    qa_pairs.append({
                                        current_node: {
                                            "robot": current_robot_question,
                                            "custom": user_answer
                                        },
                                        "tags": tags_str
                                    })
                    else:
                        # answer_content 不为 null，创建新的QA对
                        if current_robot_question and current_node:
                            if len(qa_pairs) <= 0:
                                qa_pairs.append({
                                    current_node: {
                                        "robot": current_robot_question,
                                        "custom": user_answer
                                    },
                                    "tags": tags_str
                                })
                            else:
                                last_qa = qa_pairs[-1]
                                # 检查最后一个QA对是否是当前节点
                                if current_node in last_qa:
                                    # 合并用户回答
                                    last_qa[current_node]['custom'] += ',' + user_answer
                                    # 更新tags（如果新的有tags）
                                    if tags_str:
                                        last_qa['tags'] = tags_str
                                else:
                                    # 如果节点不同，创建新QA对
                                    if current_robot_question:
                                        qa_pairs.append({
                                            current_node: {
                                                "robot": current_robot_question,
                                                "custom": user_answer
                                            },
                                            "tags": tags_str
                                        })

                # 再处理机器人新问题（如果存在）
                if record.get('answer_content'):
                    robot_text = ""
                    node_name = record.get('answer_text', '')
                    if "Q" not in node_name:
                        contents = record['contents']
                        for content in contents:
                            if "Q" in content['translate_text']:
                                node_name = content['translate_text'].split(":")[0]
                                break

                    # 从 contents 中提取文本
                    if record.get('contents'):
                        robot_text = ' '.join([c['translate_text'] for c in record['contents']])
                    else:
                        content = record['answer_content']
                        lines = content.split('\n')
                        robot_text = '\n'.join([line for line in lines if not line.strip().endswith('秒')])

                    # 清理文本
                    robot_text = robot_text.strip()
                    if ':' in robot_text:
                        parts = robot_text.split(':', 1)
                        if parts[0] in ['Q1', 'Q2', 'Q3', 'Q4', 'Q5', 'Q6', 'Q7', 'Q1-A', 'Q1-default']:
                            robot_text = parts[1].strip()

                    current_robot_question = robot_text
                    current_node = node_name
                if idx == len(records) - 1:
                    # 处理最后一条记录，如果是用户回答但没有对应的机器人问题
                    if current_robot_question and current_node:
                        tags_list = []

                        tags_str = ','.join(tags_list) if tags_list else ''
                        qa_pairs.append({
                            current_node: {
                                "robot": current_robot_question,
                                "custom": ""
                            },
                            "tags": ""
                        })
        return qa_pairs


    async def _get_agent_api_config(self) -> tuple[str, str]:
        """获取 Agent API 配置。"""
        base_url = 'http://188.107.245.58:19999'
        token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxMyIsImp0aSI6IjQ0ZDM1YzI3YWMxNWI0MGRlNGRlZGU0Zjc5NzhlZWUxYzM3MTZiMjZmZDZmOTljMGUzMmRiNWU5MmI3OGY5NTJlNDVlNTNhMWFmMTA2YzUzIiwiaWF0IjoxNzc0MDg5NzA4LCJuYmYiOjE3NzQwODk3MDgsImV4cCI6MTgwNTYyNTcwOCwic3ViIjoiOWFhMmM3MjItMTJiYS00ZDljLTgwNTYtNzU3NDYxY2RlZDVlIiwic2NvcGVzIjpbXX0.ACIJTMdmp3N9qBFriQIwbB_GI5K9MJmEPbsL9-qsg6UiyhqZfPPRJ8ZwHIjURANOEQPrxIHXuAWAu6SP-6PSn0BOwQDd275FpXxV-Wgwow98Z_uKcXZKGyPoiRnqcJdenKctGgcA2xdRqoRWv2n1UW82HdR6wWkwAKggZRzXOj_kULz80mStaWOiVZdrunh5ff8qFEStmc59bRLIl-4y744x1XhIEsnHmiJ1zHuCBEpRKRo0NkRQnJFCHfvLdhWCnlZk9MJCa7x8_0nNKMBk0fPoQshJ9Qcb7vi5k_JSmtNO8dQAlGlQgCzcADRbw0VAQ3qAPqzpIPPHzBVYCqCJ6PRlR4DghVWAfbMcJomih0gnxqOg6jkj4AoRPhW94RBDYQm-elnZWEKWW4j2TNJm9cifWaoq-UKpAAyT54n-rVmw1XJzqW73BGy1UNadBhSA_w6T3xl5xdtjtOLJ7ybEgoH5KEhSuhNS7dcB2x53E3ftstEvP7c2FelEiLoCidNLiRXidyAswNa0JiT20YLC_LJ3qMMJud3hHEUgIG3pxVClPazOcIAja2Vriwgy4gt9Ygbpg-c2huqgKQpeNM1TQ_jw0QClprsanuAFmYIGj1muhVOIA1HnSbffvZg63TmXib-nYTyrRl-HkOYLkuN5O7mk6wMiyg7t8mDwnWjWuFk'
        if not base_url or not token:
            raise RuntimeError(
                "缺少 Agent API 配置：请在 .env 中设置 AGENT_API_BASE_URL 和 AGENT_API_TOKEN"
            )

        return base_url, token

    def _fetch_agent_detail_json(
        self,
        base_url: str,
        token: str,
        user_id: str,
        task_id: str,
        record_id: str,
        timeout_s: int = 10,
    ) -> dict:
        """同步调用 ASR 明细接口并返回 JSON。"""
        url = f"{base_url}/agent-api/user/{user_id}/task/{task_id}/detail/{record_id}"
        logger.info(f"url: {url}, task_id:{task_id}")
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        }

        resp = requests.get(url, headers=headers, timeout=timeout_s)
        if resp.status_code != 200:
            raise RuntimeError(
                f"Agent API 请求失败 status={resp.status_code}, body={resp.text[:500]}"
            )
        return resp.json()


    async def _batch_fetch_asr_details(
        self,
        call_ids: list[tuple[str, date]],
    ) -> dict[str, dict]:
        """
        批量获取 ASR 详情 (支持跨月查询)

        Args:
            call_ids: [(callid, call_date), ...] 通话ID和日期的元组列表

        Returns:
            {callid: {'user_text': str, 'asr_labels': list}}
        """
        if not call_ids:
            return {}

        # 提取所有日期,确定涉及的月份范围
        dates = [call_date for _, call_date in call_ids]
        min_date = min(dates)
        max_date = max(dates)

        # 获取涉及的所有分表
        tables = get_tables_for_period(min_date, max_date, "call_record")
        logger.info(f"跨月查询涉及 {len(tables)} 张表: {tables}")

        # 提取所有 callid
        callid_list = [c[0] for c in call_ids]
        # 构建参数占位符
        placeholders = ", ".join([f":callid_{i}" for i in range(len(callid_list))])
        params = {f"callid_{i}": callid for i, callid in enumerate(callid_list)}

        # 为每个表构建子查询（仅返回接口定位字段）
        subqueries: list[str] = []
        for table in tables:
            subqueries.append(
                f"""
                SELECT
                    id,
                    user_id,
                    task_id,
                    callid
                FROM autodialer_call_record_2026_03
                WHERE callid IN ({placeholders})
                """
            )

        # UNION ALL 合并所有子查询
        union_sql = " UNION ALL ".join(subqueries)

        sql = text(
            f"""
            SELECT * FROM ({union_sql}) AS combined
            ORDER BY callid ASC
            """
        )

        # 先从 DB 拉取定位 rows
        try:
            base_url, token = await self._get_agent_api_config()
            logger.info(f"base_url: {base_url}")
        except Exception as e:
            logger.error(f"Agent API 配置缺失，无法拉取 ASR 明细: {e}")
            return {}

        result_map: dict[str, dict] = {}

        async for session in get_source_db():
            try:
                result = await session.execute(sql, params)
                rows = result.fetchall()
                for i, row in enumerate(rows):
                    callid = row.callid
                    user_id = str(row.user_id)
                    task_id = str(row.task_id)
                    record_id = str(row.id)

                    detail_json = await asyncio.to_thread(
                        self._fetch_agent_detail_json,
                        base_url,
                        token,
                        user_id,
                        task_id,
                        record_id,
                        10,
                    )
                    qa_pairs = await self.extract_qa_pairs(detail_json)
                    voice_url = await self.extract_voice_urls(detail_json)
                    result_map[callid] = {
                        "qa_pairs": qa_pairs,
                        "task_id": task_id,
                        "voice_url": voice_url
                    }

            except Exception as e:
                logger.error(f"批量获取 ASR 详情失败 (涉及表: {tables}): {e}")

        return result_map

    async def _batch_update_analysis_results(
        self,
        updates: list[dict],
    ) -> None:
        """批量更新分析结果到数据库（优化版：使用 VALUES 批量更新）"""
        if not updates:
            return

        async for session in get_portrait_db():
            analyzed_at = datetime.now()

            # 批量执行更新（分批处理避免参数过多）
            batch_size = 100
            for i in range(0, len(updates), batch_size):
                batch = updates[i : i + batch_size]

                # 构建 VALUES 子句和参数
                values_parts = []
                params = {"analyzed_at": analyzed_at}

                for idx, update in enumerate(batch):
                    values_parts.append(
                        f"(:callid_{idx}, :qa_pairs_{idx}, :satisfaction_{idx}, :satisfaction_source_{idx},:satisfaction_llm_res_{idx}, "
                        f":emotion_{idx}, :emotion_llm_res_{idx}, :emotion_asr_res_{idx}, :complaint_risk_{idx}, :complaint_llm_res_{idx}, :churn_risk_{idx}, :churn_llm_res_{idx},"
                        f":willingness_{idx}, :risk_level_{idx}, :unsatisfied_reason_{idx}, :visit_needed_{idx}, :visit_reason_{idx}, :harassment_risk_{idx}, :harassment_llm_res_{idx})"
                    )
                    params[f"callid_{idx}"] = update["callid"]
                    params[f"qa_pairs_{idx}"] = update["qa_pairs"]
                    params[f"satisfaction_{idx}"] = update["satisfaction"]
                    params[f"satisfaction_source_{idx}"] = update["satisfaction_source"]
                    params[f"satisfaction_llm_res_{idx}"] = update["satisfaction_llm_res"]
                    params[f"emotion_{idx}"] = update["emotion"]
                    params[f"emotion_llm_res_{idx}"] = update["emotion_llm_res"]
                    params[f"emotion_asr_res_{idx}"] = update["emotion_asr_res"]
                    params[f"complaint_risk_{idx}"] = update["complaint_risk"]
                    params[f"complaint_llm_res_{idx}"] = update["complaint_llm_res"]
                    params[f"churn_risk_{idx}"] = update["churn_risk"]
                    params[f"churn_llm_res_{idx}"] = update["churn_llm_res"]
                    params[f"willingness_{idx}"] = update["willingness"]
                    params[f"risk_level_{idx}"] = update["risk_level"]
                    params[f"unsatisfied_reason_{idx}"] = update["unsatisfied_reason"]
                    params[f"visit_needed_{idx}"] = update["visit_needed"]
                    params[f"visit_reason_{idx}"] = update["visit_reason"]
                    params[f"harassment_risk_{idx}"] = update["harassment_risk"]
                    params[f"harassment_llm_res_{idx}"] = update["harassment_llm_res"]

                # 使用 PostgreSQL VALUES + UPDATE FROM 语法批量更新
                values_sql = ", ".join(values_parts)
                await session.execute(
                    text(f"""
                        UPDATE call_record_enriched AS c
                        SET 
                            qa_pairs = v.qa_pairs,
                            satisfaction = v.satisfaction,
                            satisfaction_source = v.satisfaction_source,
                            satisfaction_llm_res = v.satisfaction_llm_res,
                            sentiment = v.emotion,
                            emotion_llm_res = v.emotion_llm_res,
                            emotion_asr_res = v.emotion_asr_res,
                            complaint_risk = v.complaint_risk,
                            complaint_llm_res = v.complaint_llm_res,
                            churn_risk = v.churn_risk,
                            churn_llm_res = v.churn_llm_res,
                            willingness = v.willingness,
                            risk_level = v.risk_level,
                            unsatisfied_reason = v.unsatisfied_reason,
                            visit_needed = v.visit_needed,
                            visit_reason = v.visit_reason,
                            harassment_risk = v.harassment_risk,
                            harassment_llm_res = v.harassment_llm_res,
                            llm_analyzed_at = :analyzed_at
                        FROM (VALUES {values_sql}) AS v(
                            callid, qa_pairs, satisfaction, satisfaction_source, satisfaction_llm_res,
                            emotion, emotion_llm_res,emotion_asr_res, complaint_risk,complaint_llm_res, churn_risk,churn_llm_res, 
                            willingness, risk_level, unsatisfied_reason,visit_needed,visit_reason,harassment_risk,harassment_llm_res
                        )
                        WHERE c.callid = v.callid
                    """),
                    params,
                )

                # 每批次提交一次
                await session.commit()
                logger.info(f"已更新分析结果: {min(i + batch_size, len(updates))}/{len(updates)}")

    async def get_call_details(
        self,
        callid: str,
        task_create_date: date,
    ) -> list[dict]:
        """
        获取通话的 ASR 详情

        Args:
            callid: 通话ID
            task_create_date: 任务创建日期 (用于确定表名)

        Returns:
            对话详情列表
        """
        if not is_source_db_available():
            return []

        table_name = get_call_record_detail_table(task_create_date)

        sql = text(f"""
            SELECT 
                sequence,
                question,
                answer_text,
                speak_ms,
                created_at
            FROM {table_name}
            WHERE callid = :callid
              AND notify = 'asrmessage_notify'
            ORDER BY sequence ASC
        """)

        details = []
        async for session in get_source_db():
            try:
                result = await session.execute(sql, {"callid": callid})
                rows = result.fetchall()

                for row in rows:
                    details.append(
                        {
                            "sequence": row.sequence,
                            "question": row.question,  # 用户说话内容 (ASR)
                            "answer_text": row.answer_text,  # 机器人回复
                            "speak_ms": row.speak_ms,
                            "created_at": row.created_at,
                        }
                    )
            except Exception as e:
                logger.error(f"读取通话详情失败: {e}")
                if "doesn't exist" in str(e):
                    logger.warning(f"表 {table_name} 不存在")

        return details

    async def get_asr_text_for_analysis(
        self,
        callid: str,
        task_create_date: date,
    ) -> str:
        """
        获取通话的完整 ASR 文本用于 LLM 分析

        Args:
            callid: 通话ID
            task_create_date: 任务创建日期

        Returns:
            拼接的对话文本
        """
        details = await self.get_call_details(callid, task_create_date)

        if not details:
            return ""

        # 拼接对话文本
        dialogues = []
        for d in details:
            if d["question"]:
                dialogues.append(f"客户: {d['question']}")
            if d["answer_text"]:
                dialogues.append(f"机器人: {d['answer_text']}")

        return "\n".join(dialogues)

    async def get_pending_records_for_analysis(
        self,
        limit: int = 100,
    ) -> list[CallRecordEnriched]:
        """
        获取待 LLM 分析的记录

        Args:
            limit: 最大返回数量

        Returns:
            待分析的记录列表
        """
        async for session in get_portrait_db():
            result = await session.execute(
                text("""
                    SELECT * FROM call_record_enriched
                    WHERE llm_analyzed_at IS NULL
                      AND bill > 0
                    ORDER BY call_date DESC
                    LIMIT :limit
                """),
                {"limit": limit},
            )
            rows = result.fetchall()
            return [CallRecordEnriched(**dict(row._mapping)) for row in rows]

        return []

    async def sync_task_names(self) -> dict[str, Any]:
        """
        同步任务名称到画像系统

        从源数据库获取任务名称，更新到 TaskPortraitSummary 表

        Returns:
            同步结果统计
        """
        if not is_source_db_available():
            logger.warning("MySQL 源数据库不可用，跳过任务名称同步")
            return {"status": "skipped", "reason": "source_db_unavailable"}

        logger.info("开始同步任务名称")

        # 从源数据库获取任务信息
        task_map = await self._fetch_task_names()
        if not task_map:
            logger.info("没有需要同步的任务")
            return {"status": "success", "synced": 0}

        logger.info(f"从源库读取到 {len(task_map)} 个任务")

        # 更新 TaskPortraitSummary 表中的任务名称
        updated_count = 0
        async for session in get_portrait_db():
            try:
                from src.models import TaskPortraitSummary

                for task_id, task_name in task_map.items():
                    # 更新所有该任务的汇总记录
                    stmt = text("""
                        UPDATE task_portrait_summary
                        SET task_name = :task_name
                        WHERE task_id = :task_id AND (task_name IS NULL OR task_name != :task_name)
                    """)
                    result = await session.execute(stmt, {"task_id": task_id, "task_name": task_name})
                    updated_count += result.rowcount

                await session.commit()
            except Exception as e:
                logger.error(f"更新任务名称失败: {e}")
                await session.rollback()
                raise

        logger.info(f"任务名称同步完成: 更新 {updated_count} 条记录")
        return {
            "status": "success",
            "tasks": len(task_map),
            "updated": updated_count,
        }

    async def _fetch_task_names(self) -> dict[str, str]:
        """
        从源数据库获取任务名称映射

        Returns:
            {task_id: task_name} 映射
        """
        sql = text("""
            SELECT uuid, name
            FROM autodialer_task
            WHERE name IS NOT NULL AND name != ''
        """)

        task_map = {}
        async for session in get_source_db():
            try:
                result = await session.execute(sql)
                rows = result.fetchall()

                for row in rows:
                    task_map[row.uuid] = row.name
            except Exception as e:
                logger.error(f"读取任务名称失败: {e}")
                raise

        return task_map

    async def get_task_name(self, task_id: str) -> str | None:
        """
        获取单个任务的名称

        Args:
            task_id: 任务UUID

        Returns:
            任务名称，未找到返回 None
        """
        if not is_source_db_available():
            return None

        sql = text("""
            SELECT name FROM autodialer_task WHERE uuid = :task_id
        """)

        async for session in get_source_db():
            try:
                result = await session.execute(sql, {"task_id": task_id})
                row = result.fetchone()
                return row.name if row else None
            except Exception as e:
                logger.error(f"获取任务名称失败: {e}")
                return None

        return None


# 全局服务实例
etl_service = ETLService()
